#########################################################################
###########                                                 #############
###########    Web service calls - Programming Assignment   #############
###########                                                 #############
###########                  Main.py                        #############
#########################################################################


from flask_restful import Api, Resource               # install the packages flask_restful, Api, Resource
from flask import request, jsonify, Flask, Blueprint  # install the packages flask, request, jsonify, Flask, Blueprint
from sc1 import function_sc1
from sc2 import function_sc2
from sc3 import function_sc3
from sc4 import function_sc4
from sc5 import function_sc5

class SomeClass(Resource):
    def get(self):

        someVar = request.args.get('somevar')   # get some var from Web application
        quer = someVar.split('_')               # use '_' to split the variables

        query_type = quer[0]                    # the first variable determines query type (i.e. sc1, sc2, sc3 ....)
        type_var = quer[1]                      # the second variable determines the variable type (i.e search by id)
        var1 = quer[2]
        var2 = quer[3]
        var3 = quer[4]

        #print 'query[0]=' + query_type
        #print 'query[1]=' + type_var
        #print 'query[2]=' + var1
        #print 'query[3]=' + var2
        #print 'query[4]=' + var3

###############################################
####      select one of the 5 queries     #####
###############################################

        # 1st Query -> http://localhost:9090/user/query/?somevar=sc1_X_Y__
        if query_type == 'sc1':         # if query_type is sc1, the first query is executed
            if type_var == 'id':        # http://localhost:9090/user/query/?somevar=sc1_id_number__
                function_sc1(0, var1)
            elif type_var == 'title':   # http://localhost:9090/user/query/?somevar=sc1_title_string__
                function_sc1(var1, 0)

        # 2nd Query -> http://localhost:9090/user/query/?somevar=sc2_X_Y_Z_W
        elif query_type == 'sc2':       # if query_type is sc2, the second query is executed
            if type_var == 'id':        # http://localhost:9090/user/query/?somevar=sc2_id_number__
                function_sc2(var1, 0, 0)
            elif type_var == 'fname':   # http://localhost:9090/user/query/?somevar=sc2_fname_string__
                function_sc2(0, var1, ' ')
            elif type_var == 'lname':   # http://localhost:9090/user/query/?somevar=sc2_lname_string__
                function_sc2(0,' ',var1)
            elif type_var == 'flname':
                function_sc2(0, var1, var2)  # http://localhost:9090/user/query/?somevar=sc2_flname_string1_string2_

        # 3rd Query -> http://localhost:9090/user/query/?somevar=sc3_X_Y_Z_W
        elif query_type == 'sc3':
            if type_var == 'id':          # http://localhost:9090/user/query/?somevar=sc3_id_number__
                function_sc3(var1, 0, 0)
            elif type_var == 'fname':      # http://localhost:9090/user/query/?somevar=sc3_fname_string__
                function_sc3(0, var1, ' ')
            elif type_var == 'lname':      # http://localhost:9090/user/query/?somevar=sc3_lname_string__
                function_sc3(0,' ',var1)
            elif type_var == 'flname':     # http://localhost:9090/user/query/?somevar=sc3_flname_string1_string2_
                function_sc3(0, var1, var2)

        # 4th Query -> http://localhost:9090/user/query/?somevar=sc4_X_Y_Z_W
        elif query_type == 'sc4':
            if type_var == 'genreyear':   # http://localhost:9090/user/query/?somevar=sc4_genreyear_string_number_
                function_sc4(var1, var2, 0)
            elif type_var == 'genreyearend':   # http://localhost:9090/user/query/?somevar=sc4_genreyear_str_num1_num2
                function_sc4(var1,var2,var3)

        # 5th Query -> http://localhost:9090/user/query/?somevar=sc5_X_Y_Z_W
        elif query_type == 'sc5':
            if type_var == 'year':     # http://localhost:9090/user/query/?somevar=sc5_year_number__
                function_sc5(var1, 0)
            elif type_var == 'yearend': # http://localhost:9090/user/query/?somevar=sc5_yearend_number1_number2_
                function_sc5(var1,var2)


api_bp = Blueprint('api', __name__)
api = Api(api_bp)
api.add_resource(SomeClass, '/user/query/')

app = Flask(__name__)
app.register_blueprint(api_bp)

@app.route('/')
def index():
    return jsonify({'status': 200, 'success': True})
app.run(host='localhost', port=9090)