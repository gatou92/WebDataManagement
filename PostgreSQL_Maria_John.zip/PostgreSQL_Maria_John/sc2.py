import psycopg2
def function_sc2( act_id, f_name, l_name ):



    try:
        conn = psycopg2.connect("dbname='IMDB' user='postgres' host='localhost' password='476133'")
        print "Successful Connection"
    except:
        print "I am unable to connect to the database"

    cur = conn.cursor()

    if act_id != 0:
        cur.execute(""" SELECT a.idactors, a.fname, a.lname,  a.gender  
                        FROM actors a             
                        WHERE a.idactors= %s   """, [act_id])

        results1 = cur.fetchall()
        cur.execute(""" SELECT DISTINCT m.idmovies, m.title, m.year 
                            FROM movies m 
                            JOIN acted_in ai 
                            ON m.idmovies = ai.idmovies 
                            JOIN actors a 
                            ON a.idactors = ai.idactors 
                            WHERE a.idactors = %s
                            ORDER BY m.year """, [act_id])
        results2 = cur.fetchall()

        final = results1 + results2
        print final

    if act_id == 0:

        first_name = '%' + f_name + '%'
        last_name = '%' + l_name + '%'

        cur.execute(""" SELECT a.idactors, a.fname, a.lname,  a.gender  
                        FROM actors a             
                        WHERE a.fname ILIKE %s AND a.lname ILIKE %s """, [first_name, last_name])

        results1 = cur.fetchall()
        cur.execute(""" SELECT DISTINCT m.idmovies, m.title, m.year 
                            FROM movies m 
                            JOIN acted_in ai 
                            ON m.idmovies = ai.idmovies 
                            JOIN actors a 
                            ON a.idactors = ai.idactors 
                            WHERE a.fname ILIKE %s AND a.lname ILIKE %s
                            ORDER BY m.year """, [first_name, last_name])
        results2 = cur.fetchall()

        final1 = results1 + results2

        print final1