import psycopg2

def function_sc1( title, id ):

    try:
        conn = psycopg2.connect("dbname='IMDB' user='postgres' host='localhost' password='476133'")
        print "Successful Connection"
    except:
        print "I am unable to connect to the database"

    cur = conn.cursor()

    id_var = id
    title_var = title

    if id_var !=0 :


        cur.execute(""" SELECT  m.title,  m.year  AS full_title
                        FROM movies m
                        WHERE m.idmovies = %s
                        ORDER BY m.year """, [id_var])

        results1 = cur.fetchall()
        cur.execute(""" SELECT DISTINCT a.idactors, a.fname, a.lname, a.gender, ai.character, ai.billing_position  
                       FROM actors a 
                       JOIN acted_in ai 
                       ON a.idactors = ai.idactors 
                       JOIN movies m 
                       ON m.idmovies = ai.idmovies 
                       WHERE m.idmovies = %s
                       ORDER BY ai.billing_position """, [id_var])
        results2 = cur.fetchall()
        cur.execute("""SELECT DISTINCT g.idgenres, g.genre 
                       FROM genres g 
                       JOIN movies_genres mg 
                       ON g.idgenres = mg.idgenres 
                       JOIN movies m 
                       ON m.idmovies = mg.idmovies 
                       WHERE m.idmovies = %s
                       ORDER BY g.idgenres """, [id_var])

        results3 = cur.fetchall()

        cur.execute(""" SELECT DISTINCT k.idkeywords, k.keyword 
                       FROM keywords k 
                       JOIN movies_keywords mk 
                       ON k.idkeywords = mk.idkeywords 
                       JOIN movies m 
                       ON m.idmovies = mk.idmovies 
                       WHERE m.idmovies = %s
                       ORDER BY k.idkeywords """, [id_var])

        results4 = cur.fetchall()

        cur.execute(""" SELECT DISTINCT s.idseries, s.name, s.season, s.number 
                       FROM series s 
                       JOIN movies m 
                       ON m.idmovies = s.idmovies 
                       WHERE m.idmovies = %s
                       ORDER BY s.idseries""", [id_var])

        results5 = cur.fetchall()

        #print "\nShow me the databases:\n"

        final = results1 + results3 + results2 + results4 + results5
        print final
        return final


    ##################################################################
    ##################################################################
    if title_var != 0:

        title_var = '%' + title + '%'

        cur.execute(""" SELECT  m.title,  m.year  AS full_title
                 FROM movies m
                 WHERE m.title ILIKE %s  AND type=3
                 ORDER BY m.year  """, [title_var])
#AND m.idmovies NOT IN (SELECT DISTINCT m.idmovies FROM movies m JOIN series s ON m.idmovies = s.idmovies WHERE m.title ILIKE %s  Maybe malakia
        results1 = cur.fetchall()
        cur.execute(""" SELECT DISTINCT a.idactors, a.fname,a.lname, a.gender, ai.character, ai.billing_position  
                FROM actors a 
                JOIN acted_in ai 
                ON a.idactors = ai.idactors 
                JOIN movies m 
                ON m.idmovies = ai.idmovies 
                WHERE m.title ILIKE %s and type=3
                ORDER BY ai.billing_position """, [title_var])
        results2 = cur.fetchall()
        cur.execute("""SELECT DISTINCT g.idgenres, g.genre 
                FROM genres g 
                JOIN movies_genres mg 
                ON g.idgenres = mg.idgenres 
                JOIN movies m 
                ON m.idmovies = mg.idmovies 
                WHERE m.title ILIKE %s and type=3
                ORDER BY g.idgenres """, [title_var])

        results3 = cur.fetchall()

        cur.execute(""" SELECT DISTINCT k.idkeywords, k.keyword 
                FROM keywords k 
                JOIN movies_keywords mk 
                ON k.idkeywords = mk.idkeywords 
                JOIN movies m 
                ON m.idmovies = mk.idmovies 
                WHERE m.title ILIKE %s and type=3
                ORDER BY k.idkeywords """, [title_var])

        results4 = cur.fetchall()

        cur.execute(""" SELECT DISTINCT s.idseries, s.name, s.season, s.number 
                FROM series s 
                JOIN movies m 
                ON m.idmovies = s.idmovies 
                WHERE m.title ILIKE %s and type=3
                ORDER BY s.idseries""", [title_var])

        results5 = cur.fetchall()


        final1 = results1 + results3 + results2 + results4 + results5
        print final1

