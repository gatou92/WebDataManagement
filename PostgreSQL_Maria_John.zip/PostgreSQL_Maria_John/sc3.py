import psycopg2

def function_sc3( act_id, f_name, l_name ):

    try:
        conn = psycopg2.connect("dbname='IMDB' user='postgres' host='localhost' password='476133'")
        print "Successful Connection"
    except:
        print "I am unable to connect to the database"

    cur = conn.cursor()

    if act_id != 0:
        cur.execute(""" SELECT a.idactors, a.fname, a.lname
                       FROM actors a             
                       WHERE a.idactors = %s   """, [act_id])

        results1 = cur.fetchall()
        cur.execute(""" SELECT COUNT(DISTINCT m.title) AS number 
                       FROM actors a 
                       JOIN acted_in ai 
                       ON a.idactors=ai.idactors 
                       JOIN movies m 
                       ON ai.idmovies=m.idmovies                
                       WHERE a.idactors = %s """, [act_id])

        results2 = cur.fetchall()

        print "\nShow me the databases:\n"

        final = results1 + results2
        print final

#######################################################################################
    if act_id == 0:

        first_name = '%' + f_name + '%'
        last_name = '%' + l_name + '%'

        cur.execute(""" SELECT a.idactors, a.fname, a.lname
                        FROM actors a             
                        WHERE a.fname ILIKE %s AND a.lname ILIKE %s  """, [first_name, last_name])

        results1 = cur.fetchall()
        cur.execute(""" SELECT COUNT(DISTINCT m.title) AS number 
                        FROM actors a 
                        JOIN acted_in ai 
                        ON a.idactors=ai.idactors 
                        JOIN movies m 
                        ON ai.idmovies=m.idmovies                
                        WHERE a.fname ILIKE %s AND a.lname ILIKE %s  """, [first_name, last_name])

        results2 = cur.fetchall()

        final1 = results1 + results2
        print final1

