import psycopg2

def function_sc4( genre, year, end_year ):
    try:
        conn = psycopg2.connect("dbname='IMDB' user='postgres' host='localhost' password='476133'")
        print "Successful Connection"
    except:
        print "I am unable to connect to the database"

    cur = conn.cursor()


    if end_year == 0:
        cur.execute(""" SELECT g.idgenres, g.genre 
                        FROM genres g             
                        WHERE g.genre = %s """, [genre])

        results1 = cur.fetchall()

        cur.execute(""" SELECT DISTINCT m.idmovies, m.title, m.year 
                        FROM movies m 
                        JOIN movies_genres mg 
                        ON mg.idmovies = m.idmovies 
                        JOIN genres g 
                        ON mg.idgenres = g.idgenres 
                        WHERE g.genre = %s
                        AND m.year >= %s
                        ORDER BY m.year, m.title   """, [genre, year])

        results2 = cur.fetchall()
        final = results1 + results2

        print final


    if end_year != 0:
        cur.execute(""" SELECT g.idgenres, g.genre 
                        FROM genres g             
                        WHERE g.genre = %s """, [genre])

        results1 = cur.fetchall()

        cur.execute(""" SELECT DISTINCT m.idmovies, m.title, m.year 
                        FROM movies m 
                        JOIN movies_genres mg 
                        ON mg.idmovies = m.idmovies 
                        JOIN genres g 
                        ON mg.idgenres = g.idgenres 
                        WHERE g.genre = %s
                        AND m.year >= %s AND m.year <= %s
                        ORDER BY m.year, m.title   """, [genre, year, end_year])

        results2 = cur.fetchall()
        final = results1 + results2

        print final

