import psycopg2

def function_sc5(year, end_year ):
    try:
        conn = psycopg2.connect("dbname='IMDB' user='postgres' host='localhost' password='476133'")
        print "Successful Connection"
    except:
        print "I am unable to connect to the database"

    cur = conn.cursor()

    if end_year == 0:
        cur.execute(""" SELECT g.idgenres, g.genre, COUNT(DISTINCT m.idmovies) AS number 
                        FROM genres g  
                        JOIN movies_genres mg  
                        ON mg.idgenres=g.idgenres  
                        JOIN movies m  
                        ON mg.idmovies = m.idmovies 
                        WHERE m.year >= %s
                        GROUP BY g.idgenres 
                        ORDER BY g.genre """, [year])

        results1 = cur.fetchall()
        final = results1

        print final

    if end_year != 0:
        cur.execute(""" SELECT g.idgenres, g.genre, COUNT(DISTINCT m.idmovies) AS number 
                        FROM genres g  
                        JOIN movies_genres mg  
                        ON mg.idgenres=g.idgenres  
                        JOIN movies m  
                        ON mg.idmovies = m.idmovies 
                        WHERE m.year >= %s AND m.year <= %s
                        GROUP BY g.idgenres 
                        ORDER BY g.genre """, [year, end_year])

        results1 = cur.fetchall()
        final = results1

        print final

